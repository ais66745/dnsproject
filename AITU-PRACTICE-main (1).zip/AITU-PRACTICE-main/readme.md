## HI THIS IS A SIMPLE WHOIS PROJECT USING GOLANG AND SOME API, also docker included

## To start just type in console

```sh
go run .
```
